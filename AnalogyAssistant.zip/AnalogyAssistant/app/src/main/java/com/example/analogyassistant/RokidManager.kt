
package com.example.analogyassistant

import android.content.Context
import android.util.Log

import com.rokid.cxr.link.CXRLink
import com.rokid.cxr.link.callbacks.ICXRLinkCbk
import com.rokid.cxr.link.callbacks.ICustomViewCbk
import com.rokid.cxr.link.utils.CxrDefs
import com.rokid.cxr.link.utils.GlassInfo

import com.example.analogyassistant.dataBean.selfView.LinearLayoutProps
import com.example.analogyassistant.dataBean.selfView.SelfViewJson
import com.example.analogyassistant.dataBean.selfView.TextViewProps
import com.example.analogyassistant.dataBean.selfView.UpdateViewJson

class RokidManager(context: Context) {

    private val TAG = "RokidManager"
    private val appContext = context.applicationContext

    private var isHudOpen = false
    private var isHudOpening = false
    private var pendingText: String? = null

    init {
        Log.e(TAG, "RokidManager 생성됨!")
    }

    // 1. CXR 연결 콜백
    private val connectCallback = object : ICXRLinkCbk {

        override fun onCXRLConnected(isConnected: Boolean) {
            Log.d(TAG, "CXR 연결: $isConnected")
        }

        override fun onGlassAiAssistStart() {
            Log.d(TAG, "AI Assist 시작")
        }

        override fun onGlassAiAssistStop() {
            Log.d(TAG, "AI Assist 종료")
        }

        override fun onGlassAiInterrupt(interruptWake: Boolean) {
            Log.d(TAG, "AI 중단: $interruptWake")
        }

        override fun onGlassBtConnected(isConnected: Boolean) {
            Log.d(TAG, "안경 Bluetooth 연결: $isConnected")
        }

        override fun onGlassDeviceInfo(deviceInfo: GlassInfo) {
            Log.d(TAG, "안경 기기 정보 수신: $deviceInfo")
        }

        override fun onGlassLauncherResume() {
            Log.d(TAG, "안경 런처 복귀")
        }

        override fun onGlassWearingStatus(wearing: Boolean) {
            Log.d(TAG, "안경 착용 상태: $wearing")
        }
    }

    // 2. HUD 콜백
    private val customViewCallback = object : ICustomViewCbk {

        override fun onCustomViewOpened() {
            Log.d(TAG, "HUD 열림 콜백 도착")

            isHudOpening = false
            isHudOpen = true

            // HUD가 열리는 동안 새 설명이 들어왔다면
            // 가장 마지막 설명을 전달
            val latestText = pendingText
            pendingText = null

            if (latestText != null) {
                sendUpdate(latestText)
            }
        }

        override fun onCustomViewUpdated() {
            Log.d(TAG, "HUD 업데이트 완료 콜백")
        }

        override fun onCustomViewClosed() {
            Log.d(TAG, "HUD 닫힘 콜백")

            isHudOpen = false
            isHudOpening = false
            pendingText = null
        }

        override fun onCustomViewIconsSent() {
            Log.d(TAG, "아이콘 전송 완료")
        }

        override fun onCustomViewError(p0: Int, p1: String?) {
            Log.e(TAG, "HUD 오류: $p0 / $p1")

            isHudOpen = false
            isHudOpening = false
        }
    }

    // 3. Rokid SDK 연결 객체
    private val cxrLink: CXRLink by lazy {
        CXRLink(appContext).apply {
            configCXRSession(
                CxrDefs.CXRSession(
                    CxrDefs.CXRSessionType.CUSTOMVIEW
                )
            )

            setCXRLinkCbk(connectCallback)
            setCXRCustomViewCbk(customViewCallback)
        }
    }

    // 4. 안경 연결
    fun connect(token: String) {
        Log.e(TAG, "connect() 호출됨! token 길이: ${token.length}")
        cxrLink.connect(token)
    }

    // 5. HUD 최초 표시
    fun showText(text: String) {
        Log.e(TAG, "HUD 표시 요청: $text")

        if (isHudOpen) {
            sendUpdate(text)
            return
        }

        if (isHudOpening) {
            pendingText = text
            Log.d(TAG, "HUD 열리는 중. 최신 텍스트 저장")
            return
        }

        isHudOpening = true
        pendingText = null

        cxrLink.customViewOpen(createView(text))
    }

    // 6. HUD 내용 갱신
    fun updateText(text: String) {
        Log.e(TAG, "HUD 갱신 요청: $text")

        when {
            isHudOpen -> {
                sendUpdate(text)
            }

            isHudOpening -> {
                // 열리는 도중에는 가장 최신 텍스트만 보관
                pendingText = text
                Log.d(TAG, "HUD 열리는 중. 업데이트 대기")
            }

            else -> {
                showText(text)
            }
        }
    }

    // 7. 실제 HUD 업데이트 전송
    private fun sendUpdate(text: String) {
        Log.e(TAG, "실제 HUD 업데이트 전송: $text")

        val update = UpdateViewJson()

        update.updateList.add(
            UpdateViewJson.UpdateJson(id = "textView").apply {
                props["text"] = text
            }
        )

        cxrLink.customViewUpdate(update.toJson())
    }

    // 8. HUD 닫기
    fun closeHud() {
        Log.e(TAG, "HUD 닫기 요청")

        if (isHudOpen || isHudOpening) {
            cxrLink.customViewClose()
        }

        isHudOpen = false
        isHudOpening = false
        pendingText = null
    }

    // 9. HUD 화면 구성
    private fun createView(text: String): String {

        val root = SelfViewJson().apply {
            type = "LinearLayout"

            props = LinearLayoutProps().apply {
                id = "root"
                layout_width = "match_parent"
                layout_height = "match_parent"
                backgroundColor = "#FF000000"
                orientation = "vertical"
                gravity = "center"
            }.toJson()

            children = listOf(
                SelfViewJson().apply {
                    type = "TextView"

                    props = TextViewProps().apply {
                        id = "textView"
                        layout_width = "wrap_content"
                        layout_height = "wrap_content"
                        this.text = text
                        textColor = "#00FF00"
                        textSize = "16sp"
                        gravity = "center"
                        textStyle = "bold"
                    }.toJson()
                }
            )
        }

        return root.toJson()
    }
}
