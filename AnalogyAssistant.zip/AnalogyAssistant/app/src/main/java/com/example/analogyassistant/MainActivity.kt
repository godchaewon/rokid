package com.example.analogyassistant

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import android.util.Log
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import com.rokid.sprite.aiapp.externalapp.auth.AuthResult
import com.rokid.sprite.aiapp.externalapp.auth.AuthorizationHelper

class MainActivity : ComponentActivity() {
    data class ExplanationCase(
        val audience: String,
        val strategy: String,
        val explanation: String
    )

    data class ExplanationEntry(
        val term: String,
        val cases: List<ExplanationCase>
    )

    private val cretaceousEntry = ExplanationEntry(
        term = "백악기",
        cases = listOf(
            ExplanationCase(
                audience = "초등 저학년",
                strategy = "익숙한 공룡을 활용한 직관적인 설명",
                explanation = "티라노사우루스가 살던 아주 오래전 시대야!"
            ),
            ExplanationCase(
                audience = "초등 고학년",
                strategy = "시대적 맥락과 상상력을 활용한 설명",
                explanation = "공룡들이 지구의 주인공이었던 시대 중 하나야."
            ),
            ExplanationCase(
                audience = "성인",
                strategy = "정확한 과학적 개념을 중심으로 한 설명",
                explanation = "백악기는 중생대의 마지막 시기로, 티라노사우루스와 트리케라톱스 등이 살았던 시대입니다."
            )
        )
    )
    private val AUTH_REQUEST_CODE = 1001

    private var rokidManager: RokidManager? = null

    private var rokidStatus by mutableStateOf(
        "Rokid 안경이 아직 연결되지 않았습니다."
    )

    private var speechRecognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())

    private val prefs by lazy {
        getSharedPreferences("analogy_dictionary", Context.MODE_PRIVATE)
    }

    private fun loadDictionary(): Map<String, String> {
        return try {
            val json = JSONObject(
                prefs.getString("dictionary", "{}") ?: "{}"
            )
            val result = mutableMapOf<String, String>()
            val keys = json.keys()

            while (keys.hasNext()) {
                val key = keys.next()
                result[key] = json.getString(key)
            }
            result
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun saveDictionary(dictionary: Map<String, String>) {
        val json = JSONObject()
        dictionary.forEach { (term, analogy) ->
            json.put(term, analogy)
        }

        prefs.edit()
            .putString("dictionary", json.toString())
            .apply()
    }

    private fun requestAI(
        text: String,
        onSuccess: (List<Pair<String, String>>) -> Unit,
        onError: (String) -> Unit
    ) {
        thread {
            var connection: HttpURLConnection? = null

            try {
                connection = URL(
                    "http://192.168.0.239:3000/extract"
                ).openConnection() as HttpURLConnection

                connection.requestMethod = "POST"
                connection.connectTimeout = 15000
                connection.readTimeout = 30000
                connection.doOutput = true

                connection.setRequestProperty(
                    "Content-Type",
                    "application/json; charset=UTF-8"
                )

                val requestBody = JSONObject()
                    .put("text", text)
                    .toString()

                connection.outputStream.use { output ->
                    output.write(requestBody.toByteArray(Charsets.UTF_8))
                }

                val responseCode = connection.responseCode

                val responseStream =
                    if (responseCode in 200..299) {
                        connection.inputStream
                    } else {
                        connection.errorStream
                    }

                val responseText = responseStream
                    ?.bufferedReader()
                    ?.use { it.readText() }
                    ?: ""

                if (responseCode !in 200..299) {
                    throw Exception(
                        "서버 응답 코드: $responseCode\n$responseText"
                    )
                }

                val json = JSONObject(responseText)

                if (!json.has("items")) {
                    throw Exception("AI 응답에 items 데이터가 없습니다.")
                }

                val items = json.getJSONArray("items")
                val extracted = mutableListOf<Pair<String, String>>()

                for (i in 0 until items.length()) {
                    val item = items.getJSONObject(i)

                    val term = item.optString("term").trim()
                    val analogy = item.optString("analogy").trim()

                    if (
                        term.isNotBlank() &&
                        analogy.isNotBlank() &&
                        term != analogy
                    ) {
                        extracted.add(term to analogy)
                    }
                }

                runOnUiThread {
                    onSuccess(extracted)
                }

            } catch (e: Exception) {
                runOnUiThread {
                    onError(e.message ?: "서버 통신에 실패했습니다.")
                }
            } finally {
                connection?.disconnect()
            }
        }
    }
    @Deprecated("Rokid SDK authorization callback")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        Log.e("RokidAuth", "🔥 onActivityResult 진입!")
        Log.e("RokidAuth", "requestCode = $requestCode")
        Log.e("RokidAuth", "resultCode = $resultCode")
        Log.e("RokidAuth", "data = $data")

        if (requestCode == AUTH_REQUEST_CODE) {
            Log.e("RokidAuth", "🔥 Rokid 인증 결과 수신!")

            val result = AuthorizationHelper.parseAuthorizationResult(
                resultCode,
                data
            )

            Log.e("RokidAuth", "인증 결과 객체 = $result")

            when (result) {
                is AuthResult.AuthSuccess -> {
                    Log.e("RokidAuth", "🔥 인증 성공! Manager 생성 시작")

                    rokidStatus = "인증 성공! 안경 연결 요청 중..."

                    rokidManager = RokidManager(this)

                    Log.e("RokidAuth", "🔥 Manager 생성 완료")

                    rokidManager?.connect(result.token)
                }

                is AuthResult.AuthFail -> {
                    Log.e("RokidAuth", "❌ 인증 실패")
                    rokidStatus = "Rokid 인증에 실패했습니다."
                }

                else -> {
                    Log.e("RokidAuth", "⚠️ 인증 취소 또는 알 수 없는 결과")
                    rokidStatus = "Rokid 인증이 취소되었습니다."
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {

                var transcript by remember { mutableStateOf("") }
                var selectedAudienceIndex by remember {
                    mutableIntStateOf(0)
                }
                var partialTranscript by remember { mutableStateOf("") }
                var resultMessage by remember { mutableStateOf("") }
                var dictionary by remember { mutableStateOf(loadDictionary()) }
                var matchedTerms by remember {
                    mutableStateOf<List<Pair<String, String>>>(emptyList())
                }
                var hudPreviewTitle by remember {
                    mutableStateOf("")
                }

                var hudPreviewBody by remember {
                    mutableStateOf("")
                }

                var isListening by remember { mutableStateOf(false) }
                var isAnalyzing by remember { mutableStateOf(false) }
                var continuousMode by remember { mutableStateOf(false) }
                var showHud by remember { mutableStateOf(false) }

                // 저장된 사전 검색

                // 저장된 사전 검색 및 앱/HUD 동시 업데이트

                fun findMatches(
                    text: String,
                    audienceIndex: Int = selectedAudienceIndex
                ) {
                    // 1. 일반 비유 사전에서 인식된 단어 검색
                    val detectedMatches = dictionary.entries
                        .filter { (term, _) ->
                            text.contains(term)
                        }
                        .map { (term, analogy) ->
                            term to analogy
                        }
                        .filter { it.first != cretaceousEntry.term }

                    // 2. 백악기가 인식되면 선택한 연령대의 설명 추가
                    val allMatches = detectedMatches.toMutableList()

                    if (text.contains(cretaceousEntry.term)) {
                        val explanation =
                            cretaceousEntry.cases[audienceIndex].explanation

                        allMatches.add(
                            cretaceousEntry.term to explanation
                        )
                    }

                    // 3. 음성에서 가장 최근에 등장한 단어를 맨 앞으로
                    val finalMatches = allMatches
                        .distinctBy { it.first }
                        .sortedByDescending { (term, _) ->
                            text.lastIndexOf(term)
                        }

                    // 4. 앱 화면 갱신
                    // 4. 앱 화면과 앱 HUD 갱신
                    matchedTerms = finalMatches

                    val latestMatch = finalMatches.firstOrNull()

                    if (latestMatch != null) {

                        // 앱 HUD에 표시할 단어
                        hudPreviewTitle = latestMatch.first

                        // 앱 HUD에 표시할 비유 설명
                        hudPreviewBody = latestMatch.second

                        // 안경 HUD에도 동일한 내용 표시
                        val hudText = """
        ${latestMatch.first}

        ${latestMatch.second}
    """.trimIndent()

                        rokidManager?.updateText(hudText)

                        Log.d("HUD_UPDATE", "앱 및 안경 HUD 갱신: $hudText")

                    } else {
                        hudPreviewTitle = ""
                        hudPreviewBody = ""
                    }
                }



                // AI 분석
                fun analyzeWithAI(text: String) {
                    if (isAnalyzing || text.isBlank()) return

                    isAnalyzing = true
                    resultMessage = "AI 분석 중..."

                    requestAI(
                        text = text,
                        onSuccess = { results ->
                            isAnalyzing = false

                            if (results.isEmpty()) {
                                resultMessage = "비유를 발견하지 못했습니다."
                            } else {
                                val updated = dictionary.toMutableMap()

                                results.forEach { (term, analogy) ->
                                    updated[term] = analogy
                                }

                                dictionary = updated
                                saveDictionary(updated)
                                findMatches(transcript + partialTranscript)

                                resultMessage = results.joinToString("\n") {
                                    "${it.first} → ${it.second}"
                                } + "\n\n저장 완료!"
                            }
                        },
                        onError = { error ->
                            isAnalyzing = false
                            resultMessage = "AI 분석 실패\n$error"
                        }
                    )
                }

                // 듣기 종료
                fun stopListening() {
                    continuousMode = false
                    isListening = false
                    partialTranscript = ""

                    handler.removeCallbacksAndMessages(null)

                    speechRecognizer?.cancel()
                    speechRecognizer?.destroy()
                    speechRecognizer = null

                    resultMessage = "연속 듣기를 중지했습니다."
                }

                // 음성인식 시작 함수
                lateinit var startListening: () -> Unit

                startListening = listening@{
                    if (!continuousMode) {
                        return@listening
                    }

                    speechRecognizer?.destroy()
                    speechRecognizer = null

                    if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                        resultMessage = "이 기기에서는 음성인식을 사용할 수 없습니다."
                        continuousMode = false
                        isListening = false
                    } else {

                        val recognizer =
                            SpeechRecognizer.createSpeechRecognizer(this)

                        speechRecognizer = recognizer

                        recognizer.setRecognitionListener(
                            object : RecognitionListener {

                                override fun onReadyForSpeech(params: Bundle?) {
                                    isListening = true
                                    resultMessage = "계속 듣는 중..."
                                }

                                override fun onBeginningOfSpeech() {}

                                override fun onRmsChanged(rmsdB: Float) {}

                                override fun onBufferReceived(
                                    buffer: ByteArray?
                                ) {}

                                override fun onEndOfSpeech() {
                                    // 발화 종료 후 최종 결과를 기다림
                                }

                                override fun onError(error: Int) {
                                    if (continuousMode) {
                                        resultMessage =
                                            "음성인식 재연결 중... (코드: $error)"

                                        handler.postDelayed({
                                            if (continuousMode) {
                                                startListening()
                                            }
                                        }, 700)
                                    } else {
                                        isListening = false
                                    }
                                }

                                override fun onResults(results: Bundle?) {
                                    val matches =
                                        results?.getStringArrayList(
                                            SpeechRecognizer.RESULTS_RECOGNITION
                                        )

                                    val finalText =
                                        matches?.firstOrNull()?.trim() ?: ""


                                    if (finalText.isNotBlank()) {
                                        Log.d("SpeechDebug", "최종 인식 결과: $finalText")

                                        transcript = (
                                                transcript + " " + finalText
                                                ).trim()

                                        partialTranscript = ""

                                        findMatches(transcript)
                                    }


                                    if (continuousMode) {
                                        handler.postDelayed({
                                            if (continuousMode) {
                                                startListening()
                                            }
                                        }, 500)
                                    } else {
                                        isListening = false
                                    }
                                }

                                override fun onPartialResults(
                                    partialResults: Bundle?
                                ) {
                                    val matches =
                                        partialResults?.getStringArrayList(
                                            SpeechRecognizer.RESULTS_RECOGNITION
                                        )

                                    val text =
                                        matches?.firstOrNull()?.trim() ?: ""

                                    if (text.isNotBlank()) {
                                        partialTranscript = text

                                        findMatches(
                                            transcript + " " + partialTranscript
                                        )
                                    }
                                }

                                override fun onEvent(
                                    eventType: Int,
                                    params: Bundle?
                                ) {}
                            }
                        )

                        val intent = Intent(
                            RecognizerIntent.ACTION_RECOGNIZE_SPEECH
                        ).apply {
                            putExtra(
                                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                            )

                            putExtra(
                                RecognizerIntent.EXTRA_LANGUAGE,
                                "ko-KR"
                            )

                            putExtra(
                                RecognizerIntent.EXTRA_PARTIAL_RESULTS,
                                true
                            )

                            putExtra(
                                RecognizerIntent.EXTRA_MAX_RESULTS,
                                1
                            )
                        }

                        try {
                            recognizer.startListening(intent)
                        } catch (e: Exception) {
                            resultMessage =
                                "음성인식 시작 실패: ${e.message}"

                            handler.postDelayed({
                                if (continuousMode) {
                                    startListening()
                                }
                            }, 700)
                        }
                    }
                }

                // 마이크 권한
                val permissionLauncher =
                    rememberLauncherForActivityResult(
                        ActivityResultContracts.RequestPermission()
                    ) { granted ->
                        if (granted) {
                            transcript = ""
                            partialTranscript = ""
                            matchedTerms = emptyList()
                            continuousMode = true
                            startListening()
                        } else {
                            resultMessage = "마이크 권한이 필요합니다."
                        }
                    }

                // UI
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {

                    Text(
                        text = "Smart Curator",
                        style = MaterialTheme.typography.headlineMedium
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "AI 도슨트 비유 수집기",
                        style = MaterialTheme.typography.titleMedium
                    )

                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "👓 Rokid Glasses 연결",
                        style = MaterialTheme.typography.titleMedium
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            Log.e("RokidAuth", "🔥 인증 버튼 클릭!")

                            try {
                                val result = AuthorizationHelper.requestAuthorization(
                                    activity = this@MainActivity,
                                    requestCode = AUTH_REQUEST_CODE
                                )

                                if (result != null) {
                                    Log.e("RokidAuth", "🔥 SDK 인증 결과 수신!")
                                    Log.e("RokidAuth", "resultCode = ${result.first}")

                                    // 반환된 Pair를 직접 인증 결과로 파싱
                                    val authResult =
                                        AuthorizationHelper.parseAuthorizationResult(
                                            result.first,
                                            result.second
                                        )

                                    Log.e("RokidAuth", "인증 파싱 결과 = $authResult")

                                    when (authResult) {
                                        is AuthResult.AuthSuccess -> {
                                            Log.e("RokidAuth", "🎉 인증 성공!")

                                            rokidStatus = "인증 성공! 안경 연결 요청 중..."

                                            rokidManager = RokidManager(this@MainActivity)
                                            rokidManager?.connect(authResult.token)
                                        }

                                        is AuthResult.AuthFail -> {
                                            Log.e("RokidAuth", "❌ 인증 실패")
                                            rokidStatus = "Rokid 인증에 실패했습니다."
                                        }

                                        else -> {
                                            Log.e("RokidAuth", "⚠️ 인증 취소 또는 결과 없음")
                                            rokidStatus = "인증 결과를 확인할 수 없습니다."
                                        }
                                    }
                                } else {
                                    Log.e("RokidAuth", "❌ 인증 결과가 null")
                                    rokidStatus = "인증 결과가 반환되지 않았습니다."
                                }

                            } catch (e: Exception) {
                                Log.e("RokidAuth", "❌ Rokid 인증 오류", e)
                                rokidStatus = "인증 오류: ${e.message}"
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Rokid 인증 및 연결")
                    }

                    Button(
                        onClick = {
                            rokidManager?.showText("Hello Rokid!")
                            rokidStatus = "HUD 출력 요청 완료!"
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("안경에 Hello Rokid 띄우기")
                    }

                    Text(
                        text = rokidStatus,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "🧠 관람객 맞춤 설명",
                        style = MaterialTheme.typography.titleLarge
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "설명할 관람객의 연령대를 선택하세요.",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Spacer(modifier = Modifier.height(12.dp))


                    cretaceousEntry.cases.forEachIndexed { index, item ->

                        OutlinedButton(
                            onClick = {
                                selectedAudienceIndex = index

                                val currentText = transcript + " " + partialTranscript

                                findMatches(currentText, index)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor =
                                    if (selectedAudienceIndex == index) {
                                        MaterialTheme.colorScheme.primaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.surface
                                    }
                            )
                        ) {
                            Text(
                                text = if (selectedAudienceIndex == index) {
                                    "✓ ${item.audience}"
                                } else {
                                    item.audience
                                }
                            )
                        }
                    }


                    Spacer(modifier = Modifier.height(8.dp))


                    Button(
                        onClick = {
                            val permission =
                                ContextCompat.checkSelfPermission(
                                    this@MainActivity,
                                    Manifest.permission.RECORD_AUDIO
                                )

                            if (permission ==
                                PackageManager.PERMISSION_GRANTED
                            ) {
                                transcript = ""
                                partialTranscript = ""
                                matchedTerms = emptyList()
                                continuousMode = true
                                startListening()
                            } else {
                                permissionLauncher.launch(
                                    Manifest.permission.RECORD_AUDIO
                                )
                            }
                        },
                        enabled = !continuousMode && !isAnalyzing,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("🎤 연속 듣기 시작")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = { stopListening() },
                        enabled = continuousMode,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("⏹ 듣기 중지")
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (continuousMode) {
                            "🟢 연속 듣기 활성화"
                        } else {
                            "⚪ 듣기 종료"
                        }
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = { showHud = !showHud },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (showHud) {
                                "HUD 미리보기 닫기"
                            } else {
                                "👓 HUD 미리보기"
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (showHud) {

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = androidx.compose.ui.graphics.Color.Black
                            )
                        ) {

                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(20.dp),
                                verticalArrangement = Arrangement.Center
                            ) {

                                Text(
                                    text = "SMART CURATOR",
                                    color = androidx.compose.ui.graphics.Color.LightGray,
                                    style = MaterialTheme.typography.labelLarge
                                )

                                Spacer(modifier = Modifier.height(16.dp))


                                if (hudPreviewTitle.isBlank()) {

                                    Text(
                                        text = "발견된 비유 없음",
                                        color = androidx.compose.ui.graphics.Color.White,
                                        style = MaterialTheme.typography.headlineSmall
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = if (continuousMode) {
                                            "설명을 듣는 중..."
                                        } else {
                                            "음성인식을 시작하세요."
                                        },
                                        color = androidx.compose.ui.graphics.Color.LightGray
                                    )

                                } else {

                                    Text(
                                        text = "● ${matchedTerms.size}개 용어 발견",
                                        color = androidx.compose.ui.graphics.Color(0xFF6EE7B7),
                                        style = MaterialTheme.typography.labelLarge
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Text(
                                        text = hudPreviewTitle,
                                        color = androidx.compose.ui.graphics.Color(0xFF6EE7B7),
                                        style = MaterialTheme.typography.headlineSmall
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = hudPreviewBody,
                                        color = androidx.compose.ui.graphics.Color.White,
                                        style = MaterialTheme.typography.headlineMedium
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    Text(
                        text = "인식된 음성",
                        style = MaterialTheme.typography.titleMedium
                    )

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                transcript.ifBlank {
                                    "아직 인식된 음성이 없습니다."
                                }
                            )

                            if (partialTranscript.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = partialTranscript,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "🔎 발견된 비유",
                        style = MaterialTheme.typography.titleMedium
                    )

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            if (matchedTerms.isEmpty()) {
                                Text("현재 음성에서 발견된 비유가 없습니다.")
                            } else {
                                matchedTerms.forEach { (term, analogy) ->
                                    Column(
                                        modifier = Modifier.padding(vertical = 6.dp)
                                    ) {
                                        Text(
                                            term,
                                            style = MaterialTheme.typography.titleMedium
                                        )

                                        Text("↳ $analogy")
                                    }

                                    Divider()
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val textToAnalyze =
                                (transcript + " " + partialTranscript).trim()

                            analyzeWithAI(textToAnalyze)
                        },
                        enabled = !isAnalyzing &&
                                (transcript + partialTranscript).isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (isAnalyzing) {
                                "AI 분석 중..."
                            } else {
                                "🧠 현재 음성 AI 분석 및 비유 저장"
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                    ) {
                        Text(
                            resultMessage.ifBlank {
                                "AI 분석 결과가 여기에 표시됩니다."
                            },
                            modifier = Modifier.padding(16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "📚 설명 사전 (${dictionary.size + 1})",
                        style = MaterialTheme.typography.titleMedium
                    )

                    Spacer(modifier = Modifier.height(8.dp))

// 백악기 연령별 설명 3개
                    Card(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Text(
                                text = cretaceousEntry.term,
                                style = MaterialTheme.typography.titleLarge
                            )

                            Text(
                                text = "설명 사례 ${cretaceousEntry.cases.size}개",
                                color = MaterialTheme.colorScheme.primary
                            )

                            cretaceousEntry.cases.forEach { item ->

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = "▶ ${item.audience}",
                                    style = MaterialTheme.typography.titleMedium
                                )

                                Text(
                                    text = item.strategy,
                                    style = MaterialTheme.typography.bodySmall
                                )

                                Text(
                                    text = "↳ ${item.explanation}",
                                    style = MaterialTheme.typography.bodyMedium
                                )

                                Divider()
                            }
                        }
                    }

// 기존 AI 추출 사전
                    dictionary.forEach { (term, analogy) ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp)
                            ) {
                                Text(
                                    text = term,
                                    style = MaterialTheme.typography.titleMedium
                                )

                                Text("↳ $analogy")
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f)
                    ) {
                        items(
                            dictionary.toList().sortedBy { it.first }
                        ) { item ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp)
                                ) {
                                    Text(
                                        item.first,
                                        style = MaterialTheme.typography.titleMedium
                                    )

                                    Text("↳ ${item.second}")
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = {
                            dictionary = emptyMap()
                            saveDictionary(dictionary)
                            matchedTerms = emptyList()
                            resultMessage = "비유 사전을 초기화했습니다."
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("비유 사전 초기화")
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        speechRecognizer?.cancel()
        speechRecognizer?.destroy()
        speechRecognizer = null
        super.onDestroy()
    }
}